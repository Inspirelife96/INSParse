//
//  INSReplyConstants.h
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/9.
//

#import <Foundation/Foundation.h>

# pragma mark - Replies 表

// Replies 表 ： 回复表 指用户针对回帖发表的内容，只能是文字。

// Class key
extern NSString *const INSReplyKeyClass;

// Field keys

// 标记
extern NSString *const INSReplyKeyIsLocked;
extern NSString *const INSReplyKeyIsApproved;
extern NSString *const INSReplyKeyIsDeleted;

// 核心内容
extern NSString *const INSReplyKeyContent;

// 统计字段：
extern NSString *const INSReplyLikeKeyCount;

// 关系
extern NSString *const INSReplyKeyFromUser;
extern NSString *const INSReplyKeyToPost;
extern NSString *const INSReplyKeyToReply;
