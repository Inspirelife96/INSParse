//
//  INSTopicConstants.m
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/8.
//

#import "INSTopicConstants.h"

# pragma mark - Topics 表

// Topics 表 ： 主题

// Class key
NSString *const INSTopicKeyClass = @"Topics";

// Field keys

// 标记
NSString *const INSTopicKeyIsLocked = @"isLocked";
NSString *const INSTopicKeyIsDeleted = @"isDeleted";
NSString *const INSTopicKeyIsApproved = @"isArrpoved";
NSString *const INSTopicKeyIsPopular = @"isPopular";

// 核心字段：
NSString *const INSTopicKeyTitle = @"title"; // 标题 （NSString）
NSString *const INSTopicKeyContent = @"comtent"; // 内容（NSString）
NSString *const INSTopicKeyMediaFileObjects = @"mediaFileObjects"; // 图片，可多图 (NSArray<PFFile *>)
NSString *const INSTopicKeyFromUser = @"fromUser"; // 创建者（PFUser）

// 统计字段：
NSString *const INSTopicKeyPostCount = @"postCount"; // 回帖数（NSNumber）
NSString *const INSTopicLikeKeyCount = @"likeCount"; // 点赞数（NSNumber）
NSString *const INSTopicKeyShareCount = @"shareCount"; // 分享数（NSNumber）

// 板块/话题：
NSString *const INSTopicKeyCategory = @"category"; // 标签 （INSCategory）
NSString *const INSTopicKeyTags = @"tags"; // 标签 （NSArray）
