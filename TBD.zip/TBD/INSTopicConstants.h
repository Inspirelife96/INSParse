//
//  INSTopicConstants.h
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/8.
//

#import <Foundation/Foundation.h>

// Topics 表 ： 主题

// Class key
extern NSString *const INSTopicKeyClass;

// Field keys

// 标记
extern NSString *const INSTopicKeyIsLocked;
extern NSString *const INSTopicKeyIsDeleted;
extern NSString *const INSTopicKeyIsPrivate;
extern NSString *const INSTopicKeyIsApproved;
extern NSString *const INSTopicKeyIsPopular;

// 核心字段：
extern NSString *const INSTopicKeyTitle; // 标题 （NSString）
extern NSString *const INSTopicKeyContent; // 内容（NSString）
extern NSString *const INSTopicKeyMediaFileObjects; // 图片，可多图 (NSArray<PFFile *>)
extern NSString *const INSTopicKeyFromUser; // 创建者（PFUser）

// 统计字段：
extern NSString *const INSTopicKeyPostCount; // 回帖数（NSNumber）
extern NSString *const INSTopicLikeKeyCount; // 点赞数（NSNumber）
extern NSString *const INSTopicKeyShareCount; // 分享数（NSNumber）

// 板块/话题：
extern NSString *const INSTopicKeyCategory; // 标签 （INSCategory）
extern NSString *const INSTopicKeyTags; // 标签 （NSArray）


