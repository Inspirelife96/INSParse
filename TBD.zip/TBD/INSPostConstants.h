//
//  INSPostConstants.h
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/9.
//

#import <Foundation/Foundation.h>

# pragma mark - Posts 表

// Posts 表 ： 回帖

// Class key
extern NSString *const INSPostKeyClass;

// Field keys

// 标记
extern NSString *const INSPostKeyIsLocked;
extern NSString *const INSPostKeyIsApproved;
extern NSString *const INSPostKeyIsDeleted;

// 核心内容
extern NSString *const INSPostKeyContent;
extern NSString *const INSPostKeyMediaFileObjects;
extern NSString *const INSPostKeyReplies;

// 统计字段：
extern NSString *const INSPostKeyReplyCount;
extern NSString *const INSPostLikeKeyCount;

// 关系
extern NSString *const INSPostKeyFromUser;
extern NSString *const INSPostKeyToTopic;
