//
//  INSCategoryTable.m
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/15.
//

#import "INSCategoryTable.h"

@implementation INSCategoryTable

@end
