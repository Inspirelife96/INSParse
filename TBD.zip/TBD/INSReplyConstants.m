//
//  INSReplyConstants.m
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/9.
//

#import "INSReplyConstants.h"

# pragma mark - Replies 表

// Replies 表 ： 回复表 指用户针对回帖发表的内容，只能是文字。

// Class key
NSString *const INSReplyKeyClass = @"Replies";

// Field keys

// 标记
NSString *const INSReplyKeyIsLocked = @"isLocked";
NSString *const INSReplyKeyIsApproved = @"isApproved";
NSString *const INSReplyKeyIsDeleted = @"isDeleted";

// 核心内容
NSString *const INSReplyKeyContent = @"content";

// 统计字段：
NSString *const INSReplyLikeKeyCount = @"likeCount";

// 关系
NSString *const INSReplyKeyFromUser = @"fromUser";
NSString *const INSReplyKeyToPost = @"toPost";
NSString *const INSReplyKeyToReply = @"toReply";
