//
//  INSPostConstants.m
//  INSParse
//
//  Created by XueFeng Chen on 2022/5/9.
//

#import "INSPostConstants.h"

# pragma mark - Posts 表

// Posts 表 ： 回帖

// Class key
NSString *const INSPostKeyClass = @"Post";

// Field keys

// 标记
NSString *const INSPostKeyIsLocked = @"isLocked";
NSString *const INSPostKeyIsApproved = @"isApproved";
NSString *const INSPostKeyIsDeleted = @"isDeleted";

// 核心内容
NSString *const INSPostKeyContent = @"content";
NSString *const INSPostKeyMediaFileObjects = @"mediaFileObjects";
NSString *const INSPostKeyReplies = @"replies";

// 统计字段：
NSString *const INSPostKeyReplyCount = @"replyCount";
NSString *const INSPostLikeKeyCount = @"likeCount";

// 关系
NSString *const INSPostKeyFromUser = @"fromUser";
NSString *const INSPostKeyToTopic = @"toTopic";
